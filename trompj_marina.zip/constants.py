lodgings = "lodgings"
boat = "boat"
slip = "slip"